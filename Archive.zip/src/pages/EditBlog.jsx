import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Button from '../components/Button';
import ErrorMessage from '../components/ErrorMessage';
import Input from '../components/Input';
import { BobAvatar } from '../components/Navbar';

export default function EditBlog() {
  const { id } = useParams();
  const navigate = useNavigate();
  // Pending migration: get token from state.auth or localStorage via Redux thunk
  useSelector((state) => state.auth.user)

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [author, setAuthor] = useState('');

  const [fetching, setFetching] = useState(true);
  const [fetchError, setFetchError] = useState(null);

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');

  const loadBlog = async () => {
    setFetching(true);
    setFetchError(null);
    try {
      // Pending migration: dispatch a GetBlogById thunk from blogSlice
      // e.g. const result = await dispatch(GetBlogById(id));
      // then read result.payload to populate form fields
      const blogData = null;
      if (blogData) {
        setTitle(blogData.title || '');
        setDescription(blogData.description || '');
        setAuthor(blogData.author || '');
      } else {
        throw new Error('Blog entry not found in Gru Lab records.');
      }
    } catch (err) {
      setFetchError(err.message || 'Failed to fetch blog for editing.');
    } finally {
      setFetching(false);
    }
  };

  useEffect(() => {
    if (id) {
      loadBlog();
    }
  }, [id]);

  const validate = () => {
    const errs = {};
    if (!title.trim()) {
      errs.title = 'Please enter a blog title.';
    }
    if (!description.trim()) {
      errs.description = 'Please write your blog content description.';
    }
    if (!author.trim()) {
      errs.author = 'Author name is required.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    if (!token) {
      setServerError('Authentication required: You must be logged in to update this blog.');
      return;
    }

    setLoading(true);
    setServerError('');

    try {
      // Pending migration: dispatch an UpdateBlog thunk from blogSlice
      // e.g. await dispatch(UpdateBlog({ id, title, description, author }));
      navigate(`/blogs/${id}`);
    } catch (err) {
      setServerError(err.message || 'Failed to update blog entry.');
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-10 flex flex-col gap-6 animate-pulse">
        <div className="w-36 h-10 bg-surface-container-high rounded-full"></div>
        <div className="h-96 bg-surface-container-lowest rounded-3xl border-[2px] border-[#1e2a45]/20 p-6"></div>
      </div>
    );
  }

  if (fetchError) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12 flex flex-col gap-6 items-center">
        <ErrorMessage
          title="Cannot Load Blog For Editing"
          message={fetchError}
          onRetry={loadBlog}
        />
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-surface-container-high border border-[#1e2a45]/20 text-xs font-bold text-on-surface hover:bg-surface-container-highest transition-all"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Return to Feed</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-10 flex flex-col gap-6">
      {/* Top Action Bar */}
      <div className="flex items-center justify-between bg-surface-container-low p-2.5 rounded-2xl border border-[#1e2a45]/20 shadow-sm">
        <button
          type="button"
          onClick={() => navigate(`/blogs/${id}`)}
          className="flex items-center gap-1 text-on-surface px-3 py-1.5 rounded-full hover:bg-surface-container-high transition-transform active:scale-95 text-xs font-bold"
        >
          <span className="material-symbols-outlined text-[18px]">close</span>
          <span>Cancel</span>
        </button>

        {/* Mode Tag */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-secondary text-on-secondary text-xs font-extrabold shadow-[0_2px_0px_#1e2a45]">
          <span className="material-symbols-outlined text-[14px]">edit</span>
          <span>Edit Mode</span>
        </div>

        {/* Back Link */}
        <Link
          to={`/blogs/${id}`}
          className="text-xs font-bold text-secondary hover:underline px-2 py-1"
        >
          View Blog
        </Link>
      </div>

      {/* Auth Warning if not logged in */}
      {!token && (
        <div className="p-4 rounded-2xl bg-primary-container/30 border-[2px] border-[#1e2a45] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-on-surface">
            <span className="material-symbols-outlined text-[20px] text-secondary">lock</span>
            <span>You need a Bearer token to update. Please log in first!</span>
          </div>
          <Link
            to="/login"
            className="px-3 py-1.5 rounded-full bg-secondary text-on-secondary text-xs font-bold shadow-[0_2px_0px_#1e2a45] hover:bg-[#2e4d8a]"
          >
            Log In
          </Link>
        </div>
      )}

      {/* API Endpoint Badge */}
      <div className="flex items-center justify-between px-4 py-2 bg-secondary-container border border-[#1e2a45]/20 text-on-secondary-container rounded-full text-xs font-bold shadow-sm">
        <div className="flex items-center gap-2 truncate">
          <span className="material-symbols-outlined text-[18px]">bolt</span>
          <span className="font-mono truncate">PUT /api/blogs/{id} (Bearer Auth)</span>
        </div>
        <span className="material-symbols-outlined text-[16px]">verified_user</span>
      </div>

      {/* Form Card */}
      <div className="bg-surface-container-lowest rounded-3xl border-[2.5px] border-[#1e2a45] p-6 sm:p-8 shadow-[0_8px_0px_#1e2a45]">
        {/* Author Header */}
        <div className="flex items-center justify-between pb-5 mb-5 border-b border-surface-container-high">
          <div className="flex items-center gap-3">
            <div className="relative p-1 rounded-full bg-secondary-fixed border-[2px] border-[#1e2a45] shadow-sm">
              <BobAvatar className="w-10 h-10" />
            </div>
            <div>
              <span className="text-sm font-extrabold text-on-surface">
                {author || 'Minion Author'}
              </span>
              <p className="text-xs text-on-surface-variant font-medium">
                Editing Existing Lab Dispatch
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 bg-surface-container px-2.5 py-1 rounded-full text-[11px] font-bold text-on-surface">
            <span className="material-symbols-outlined text-[14px] text-secondary">save</span>
            <span>Update Mode</span>
          </div>
        </div>

        {/* Server Error Alert */}
        {serverError && (
          <div className="mb-5 p-3.5 rounded-2xl bg-tertiary-container border-[2px] border-error text-on-error-container text-xs font-bold flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px] text-error">error</span>
            <span className="flex-1">{serverError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          {/* Title Field */}
          <Input
            id="edit-title"
            name="title"
            label="Blog Title"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              if (errors.title) setErrors((prev) => ({ ...prev, title: null }));
              setServerError('');
            }}
            placeholder="Enter blog title..."
            required
            icon="edit_note"
            error={errors.title}
          />

          {/* Author Field */}
          <Input
            id="edit-author"
            name="author"
            label="Author Codename"
            value={author}
            onChange={(e) => {
              setAuthor(e.target.value);
              if (errors.author) setErrors((prev) => ({ ...prev, author: null }));
              setServerError('');
            }}
            placeholder="e.g. Stuart the Minion"
            required
            icon="badge"
            error={errors.author}
          />

          {/* Description / Body Field */}
          <Input
            as="textarea"
            rows={7}
            id="edit-description"
            name="description"
            label="Blog Story / Description"
            value={description}
            onChange={(e) => {
              setDescription(e.target.value);
              if (errors.description) setErrors((prev) => ({ ...prev, description: null }));
              setServerError('');
            }}
            placeholder="Write updated blog content..."
            required
            error={errors.description}
            helperText="Update your story or description here."
          />

          {/* Submit Action */}
          <div className="pt-2">
            <Button
              type="submit"
              variant="primary"
              size="lg"
              loading={loading}
              className="w-full text-base"
              icon="save"
            >
              Save Changes 💾
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
